
$('.owl_carousel').owlCarousel({
  singleItem: true,
  navigation: true,
  navigationText: ['<img src="img/strelka1.png" alt="">','<img src="img/strelka2.png" alt="">']
 });
$('.owl_carousel_1').owlCarousel({
  singleItem: true,
  navigation: true,
  navigationText: ['<img src="img/strelka1.png" alt="">','<img src="img/strelka2.png" alt="">']
 });